#!/usr/bin/env python3
"""Regenerate all numerical outputs and analysis figures from the 1,080-row CSV."""
from __future__ import annotations

import hashlib
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "data" / "final_pqc_quic_raw_results.csv"
RESULTS = ROOT / "results_regenerated"


def run(command: list[str]) -> None:
    print("+", " ".join(command), flush=True)
    subprocess.run(command, cwd=ROOT, check=True)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> int:
    if not RAW.is_file():
        raise FileNotFoundError(RAW)
    expected = "29ece90f482bac1280bf28d7bb6919a133dd4e305ab3449e351617490003ee54"
    actual = sha256(RAW)
    if actual != expected:
        raise RuntimeError(f"Raw-data SHA-256 mismatch: {actual}")

    if RESULTS.exists():
        shutil.rmtree(RESULTS)
    RESULTS.mkdir(parents=True)

    run([sys.executable, "analysis/reproducible_analysis.py", "--input", str(RAW), "--output", str(RESULTS)])
    # These scripts also update the canonical generated CSV/JSON files under data/.
    run([sys.executable, "analysis/robustness.py"])
    run([sys.executable, "analysis/evidence_gate_validation.py"])
    run([sys.executable, "analysis/confirmatory_planning.py"])

    # Copy the supplemental outputs produced under data/ into the regenerated result folder.
    supplemental = [
        "aggregate_group_summary.csv",
        "confirmatory_planning.json",
        "evidence_gate_truth_table.csv",
        "evidence_gate_validation.json",
        "exact_rtt_relabeling_rmse.csv",
        "h768_slope_bootstrap.csv",
        "high_delay_IQR_observations.csv",
        "manuscript_consistency_check.csv",
        "pairwise_bootstrap_effect_sizes.csv",
        "quantile_regression_interaction_tests.csv",
        "retransmission_failure_analysis.csv",
        "retransmission_fisher_tests.csv",
        "robust_location_and_deletion.csv",
        "robustness_summary.json",
    ]
    for name in supplemental:
        src = ROOT / "data" / name
        if src.exists():
            shutil.copy2(src, RESULTS / name)

    manifest_rows = []
    for path in sorted(RESULTS.rglob("*")):
        if path.is_file():
            manifest_rows.append(f"{sha256(path)}  {path.relative_to(RESULTS).as_posix()}")
    (RESULTS / "SHA256SUMS.txt").write_text("\n".join(manifest_rows) + "\n", encoding="utf-8")
    print(f"Reproduction complete: {RESULTS}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
