#!/usr/bin/env python3
"""Regenerate the V19 paper and V16-derived audit, robustness outputs, figures, PDF, and manifest."""
from __future__ import annotations

import hashlib
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "data" / "final_pqc_quic_raw_results.csv"
REANALYSIS = ROOT / "artifact" / "reanalysis"
FINAL_PDF = ROOT / "IDEASET2026_MLKEM_QUIC_Anonymous_Submission_V19.pdf"
SOURCE_MANIFEST = ROOT / "SOURCE_SHA256SUMS.txt"


def run(command: list[str]) -> None:
    print("+", " ".join(command))
    subprocess.run(command, cwd=ROOT, check=True)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def verify_source_manifest() -> None:
    """Verify immutable inputs before any generated output is replaced."""
    if not SOURCE_MANIFEST.exists():
        raise FileNotFoundError(SOURCE_MANIFEST)
    checked = 0
    for raw_line in SOURCE_MANIFEST.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        expected, relative = line.split(None, 1)
        path = ROOT / relative.strip()
        if not path.is_file():
            raise FileNotFoundError(path)
        actual = sha256(path)
        if actual != expected:
            raise RuntimeError(f"Source manifest mismatch: {relative.strip()}")
        checked += 1
    if checked == 0:
        raise RuntimeError("Source manifest contains no entries.")
    print(f"Verified {checked} immutable source files against SOURCE_SHA256SUMS.txt.")


def copy_outputs_to_artifact() -> None:
    REANALYSIS.mkdir(parents=True, exist_ok=True)
    patterns = [
        "data_audit.csv",
        "retransmission_failure_analysis.csv",
        "retransmission_fisher_tests.csv",
        "quantile_regression_interaction_tests.csv",
        "manuscript_consistency_check.csv",
        "final_pqc_quic_statistical_summary_rebuilt.csv",
        "high_delay_IQR_observations.csv",
        "aggregate_group_summary.csv",
        "pairwise_bootstrap_effect_sizes.csv",
        "robust_location_and_deletion.csv",
        "exact_rtt_relabeling_rmse.csv",
        "h768_slope_bootstrap.csv",
        "robustness_summary.json",
        "evidence_gate_truth_table.csv",
        "evidence_gate_validation.json",
        "confirmatory_planning.json",
    ]
    for name in patterns:
        src = ROOT / "data" / name
        if src.exists():
            shutil.copy2(src, REANALYSIS / name)


def write_manifest() -> None:
    excluded_suffixes = {".aux", ".log", ".fls", ".fdb_latexmk", ".out", ".synctex.gz"}
    excluded_names = {"SHA256SUMS.txt"}
    rows: list[str] = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        if path.name in excluded_names or path.suffix in excluded_suffixes:
            continue
        if ".venv" in path.parts or "__pycache__" in path.parts:
            continue
        rows.append(f"{sha256(path)}  {path.relative_to(ROOT).as_posix()}")
    (ROOT / "SHA256SUMS.txt").write_text("\n".join(rows) + "\n", encoding="utf-8")


def main() -> int:
    if not RAW.exists():
        raise FileNotFoundError(RAW)
    verify_source_manifest()
    if REANALYSIS.exists():
        shutil.rmtree(REANALYSIS)
    REANALYSIS.mkdir(parents=True)

    run([sys.executable, "analysis/reproducible_analysis.py", "--input", str(RAW), "--output", str(REANALYSIS)])
    run([sys.executable, "analysis/generate_latex_tables.py"])
    run([sys.executable, "analysis/robustness.py"])
    run([sys.executable, "analysis/evidence_gate_validation.py"])
    run([sys.executable, "analysis/confirmatory_planning.py"])
    copy_outputs_to_artifact()

    if shutil.which("latexmk"):
        run([
            "latexmk", "-pdf", "-interaction=nonstopmode", "-halt-on-error",
            "-jobname=IDEASET2026_MLKEM_QUIC_Anonymous_Submission_V19",
            "submission_anonymous.tex",
        ])
        if not FINAL_PDF.exists():
            raise FileNotFoundError(FINAL_PDF)
    else:
        print("latexmk not found; analysis regenerated but PDF was not compiled.")

    write_manifest()
    print("V19 reproduction complete.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
