from pathlib import Path
import itertools, json
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "final_pqc_quic_raw_results.csv"
OUT = ROOT / "data"
FIG = ROOT / "figures"
SEED = 20260711

alg = {
    "X25519": "X25519",
    "H-512": "X25519 + ML-KEM-512",
    "H-768": "X25519 + ML-KEM-768",
}

df = pd.read_csv(DATA)
tcol = "Handshake Time (ms)"
rtts = sorted(df["RTT (ms)"].unique())
losses = sorted(df["Packet Loss (%)"].unique())

# Deterministic robustness table.
rows = []
for short in ("H-512", "H-768"):
    for loss in losses:
        for rtt in rtts:
            x = df[(df.Algorithm == alg["X25519"]) & (df["RTT (ms)"] == rtt) & (df["Packet Loss (%)"] == loss)][tcol].to_numpy()
            y = df[(df.Algorithm == alg[short]) & (df["RTT (ms)"] == rtt) & (df["Packet Loss (%)"] == loss)][tcol].to_numpy()
            med = float(np.median(y) - np.median(x))
            trim = float(stats.trim_mean(y, 0.2) - stats.trim_mean(x, 0.2))
            hl = float(np.median((y[:, None] - x[None, :]).ravel()))
            deletion = []
            for i in range(len(y)):
                yy = np.delete(y, i)
                for j in range(len(x)):
                    xx = np.delete(x, j)
                    deletion.append(float(np.median(yy) - np.median(xx)))
            rows.append({
                "Comparison": f"{short} vs X25519",
                "RTT": int(rtt),
                "Loss": int(loss),
                "Median_difference_ms": med,
                "Trimmed20_difference_ms": trim,
                "Hodges_Lehmann_shift_ms": hl,
                "Single_deletion_min_ms": min(deletion),
                "Single_deletion_max_ms": max(deletion),
            })
rob = pd.DataFrame(rows)
rob.to_csv(OUT / "robust_location_and_deletion.csv", index=False)

# H-768 proportional descriptor and falsification diagnostics.
h = rob[rob.Comparison == "H-768 vs X25519"].sort_values(["Loss", "RTT"])
R = h.RTT.to_numpy(float)
D = h.Median_difference_ms.to_numpy(float)
beta = float((R @ D) / (R @ R))
rmse = float(np.sqrt(np.mean((D - beta * R) ** 2)))

held_errors = []
for held in rtts:
    train = h[h.RTT != held]
    rt = train.RTT.to_numpy(float)
    dt = train.Median_difference_ms.to_numpy(float)
    b = float((rt @ dt) / (rt @ rt))
    test = h[h.RTT == held]
    held_errors.extend((test.Median_difference_ms.to_numpy(float) - b * test.RTT.to_numpy(float)).tolist())
held_rmse = float(np.sqrt(np.mean(np.square(held_errors))))
held_max = float(np.max(np.abs(held_errors)))

# Exact 24^3 within-loss RTT relabeling.
rtts_arr = np.array(rtts, float)
diffs_by_loss = {loss: h[h.Loss == loss].sort_values("RTT").Median_difference_ms.to_numpy(float) for loss in losses}
rmses = []
for perms in itertools.product(itertools.permutations(range(4)), repeat=3):
    rr, dd = [], []
    for loss, perm in zip(losses, perms):
        rr.extend(rtts_arr)
        dd.extend(diffs_by_loss[loss][list(perm)])
    rr = np.array(rr, float)
    dd = np.array(dd, float)
    b = float((rr @ dd) / (rr @ rr))
    rmses.append(float(np.sqrt(np.mean((dd - b * rr) ** 2))))
rmses = np.array(rmses)
rank = int(1 + np.sum(rmses < rmse - 1e-12))
pd.DataFrame({"RMSE_ms": rmses}).to_csv(OUT / "exact_rtt_relabeling_rmse.csv", index=False)

# Bootstrap slope sensitivity (cell arrays cached for speed).
rng = np.random.default_rng(SEED)
cells = []
for loss in losses:
    for rtt in rtts:
        x = df[(df.Algorithm == alg["X25519"]) & (df["RTT (ms)"] == rtt) & (df["Packet Loss (%)"] == loss)][tcol].to_numpy()
        y = df[(df.Algorithm == alg["H-768"]) & (df["RTT (ms)"] == rtt) & (df["Packet Loss (%)"] == loss)][tcol].to_numpy()
        cells.append((float(rtt), x, y))
rr_fixed = np.array([c[0] for c in cells], dtype=float)
den = float(rr_fixed @ rr_fixed)
slopes = np.empty(5000, dtype=float)
for bidx in range(5000):
    dd = np.empty(len(cells), dtype=float)
    for idx, (_, x, y) in enumerate(cells):
        xb = x[rng.integers(0, len(x), len(x))]
        yb = y[rng.integers(0, len(y), len(y))]
        dd[idx] = np.median(yb) - np.median(xb)
    slopes[bidx] = float((rr_fixed @ dd) / den)
pd.DataFrame({"Slope_ms_per_ms": slopes}).to_csv(OUT / "h768_slope_bootstrap.csv", index=False)
lo, hi = np.quantile(slopes, [0.025, 0.975])

summary = {
    "zero_intercept_slope": beta,
    "in_sample_rmse_ms": rmse,
    "leave_one_rtt_out_rmse_ms": held_rmse,
    "leave_one_rtt_out_max_abs_error_ms": held_max,
    "exact_relabeling_rank": rank,
    "exact_relabeling_total": int(len(rmses)),
    "bootstrap_slope_ci_95": [float(lo), float(hi)],
    "seed": SEED,
}
(OUT / "robustness_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

# Figure 1: percent median differences with pointwise bootstrap CIs.
pair = pd.read_csv(OUT / "pairwise_bootstrap_effect_sizes.csv").copy()
pair["Condition"] = pair.apply(lambda z: f"{int(z.RTT)} ms / {int(z.Loss)}%", axis=1)
conditions = [f"{rtt} ms / {loss}%" for loss in losses for rtt in rtts]
ybase = np.arange(len(conditions))
fig, ax = plt.subplots(figsize=(6.6, 4.8))
for k, comp in enumerate(["H-512 vs X25519", "H-768 vs X25519"]):
    p = pair[pair.Comparison == comp].set_index("Condition").loc[conditions]
    y = ybase + (-0.13 if k == 0 else 0.13)
    x = p.Median_difference_pct.to_numpy()
    xerr = np.vstack([x - p.Median_diff_boot_CI_low.to_numpy() / p.Median_difference_ms.to_numpy() * x,
                       p.Median_diff_boot_CI_high.to_numpy() / p.Median_difference_ms.to_numpy() * x - x])
    # Avoid unstable percent-CI transformation near zero: compute CI percent using baseline medians.
    lows, highs = [], []
    for _, row in p.reset_index().iterrows():
        base_vals = df[(df.Algorithm == alg["X25519"]) & (df["RTT (ms)"] == row.RTT) & (df["Packet Loss (%)"] == row.Loss)][tcol]
        bmed = float(np.median(base_vals))
        lows.append(100.0 * row.Median_diff_boot_CI_low / bmed)
        highs.append(100.0 * row.Median_diff_boot_CI_high / bmed)
    lows = np.array(lows); highs = np.array(highs)
    xerr = np.vstack([x - lows, highs - x])
    ax.errorbar(x, y, xerr=xerr, fmt="o", capsize=2.2, label=comp)
ax.axvline(0, linewidth=0.8)
ax.set_yticks(ybase)
ax.set_yticklabels(conditions)
ax.set_xlabel("Median difference relative to X25519 (%)")
ax.set_ylabel("Configured RTT / named loss")
ax.legend(fontsize=8)
ax.grid(axis="x", alpha=0.25)
fig.tight_layout()
fig.savefig(FIG / "fig_median_percent_effects.png", dpi=300, bbox_inches="tight")
plt.close(fig)

# Figure 2: proportional H-768 archive descriptor.
fig, ax = plt.subplots(figsize=(6.2, 3.8))
for loss in losses:
    q = h[h.Loss == loss].sort_values("RTT")
    ax.plot(q.RTT, q.Median_difference_ms, marker="o", label=f"named {loss}% loss")
xx = np.linspace(min(rtts), max(rtts), 200)
ax.plot(xx, beta * xx, linestyle="--", label=f"descriptor: {beta:.5f} x RTT")
ax.set_xlabel("Configured RTT label (ms)")
ax.set_ylabel("H-768 minus X25519 median (ms)")
ax.grid(alpha=0.25)
ax.legend(fontsize=8)
fig.tight_layout()
fig.savefig(FIG / "fig_h768_scaling.png", dpi=300, bbox_inches="tight")
plt.close(fig)

print(json.dumps(summary, indent=2))
