from pathlib import Path
import csv, itertools, json

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data"
STATES = ["Pass", "Conditional", "Unavailable", "Fail"]
GATES = ["G1", "G2", "G3", "G4", "G5"]
CURRENT = {"G1":"Pass", "G2":"Pass", "G3":"Conditional", "G4":"Unavailable", "G5":"Unavailable"}
CLAIMS = {
    "C1": {"G1":{"Pass"}},
    "C2": {"G1":{"Pass"}, "G2":{"Pass"}},
    "C3": {"G1":{"Pass"}, "G2":{"Pass"}, "G3":{"Pass","Conditional"}},
    "C4": {"G1":{"Pass"}, "G2":{"Pass"}, "G3":{"Pass"}, "G4":{"Pass"}},
    "C5": {"G1":{"Pass"}, "G2":{"Pass"}, "G3":{"Pass"}, "G4":{"Pass"}, "G5":{"Pass"}},
}

def admit(req, profile):
    return all(profile[g] in allowed for g, allowed in req.items())

rows=[]
for vector in itertools.product(STATES, repeat=5):
    profile=dict(zip(GATES, vector))
    row={**profile}
    for c, req in CLAIMS.items():
        row[c]=admit(req, profile)
    rows.append(row)

with (OUT / "evidence_gate_truth_table.csv").open("w", newline="", encoding="utf-8") as f:
    w=csv.DictWriter(f, fieldnames=GATES+list(CLAIMS))
    w.writeheader(); w.writerows(rows)

current={c:admit(req,CURRENT) for c,req in CLAIMS.items()}
assert len(rows)==1024
assert sum(1 for _ in rows for _c in CLAIMS)==5120
assert current=={"C1":True,"C2":True,"C3":True,"C4":False,"C5":False}
# Independent direct expressions for the same rule.
for row in rows:
    assert row["C1"] == (row["G1"]=="Pass")
    assert row["C2"] == (row["G1"]=="Pass" and row["G2"]=="Pass")
    assert row["C3"] == (row["G1"]=="Pass" and row["G2"]=="Pass" and row["G3"] in {"Pass","Conditional"})
    assert row["C4"] == (row["G1"]==row["G2"]==row["G3"]==row["G4"]=="Pass")
    assert row["C5"] == all(row[g]=="Pass" for g in GATES)
summary={
    "gate_vectors": len(rows),
    "claim_decisions_checked": len(rows)*len(CLAIMS),
    "current_profile": CURRENT,
    "current_claims": current,
    "claim_ceiling": "C3",
    "status": "pass",
}
(OUT / "evidence_gate_validation.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
print(json.dumps(summary,indent=2))
