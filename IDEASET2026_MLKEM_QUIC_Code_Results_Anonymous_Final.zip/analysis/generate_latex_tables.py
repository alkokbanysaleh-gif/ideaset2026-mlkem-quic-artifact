from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
OUT = ROOT / 'tables'
OUT.mkdir(exist_ok=True)

summary = pd.read_csv(DATA / 'final_pqc_quic_statistical_summary_rebuilt.csv')
pairwise = pd.read_csv(DATA / 'pairwise_bootstrap_effect_sizes.csv')
qreg = pd.read_csv(DATA / 'quantile_regression_interaction_tests.csv')

order = {'X25519': 0, 'H-512': 1, 'H-768': 2}

def f2(x):
    return f'{float(x):.2f}'

def sci_p(x):
    x = float(x)
    if x < 1e-16:
        return r'$<10^{-16}$'
    if x < 0.001:
        exp = int(f'{x:.1e}'.split('e')[1])
        mant = float(f'{x:.1e}'.split('e')[0])
        return rf'${mant:.1f}\times 10^{{{exp}}}$'
    return f'{x:.3f}'

# Three per-loss scenario tables, 12 rows each.
for loss in [0, 1, 3]:
    part = summary[summary['Loss'] == loss].copy()
    part['ord'] = part['Group'].map(order)
    part = part.sort_values(['RTT', 'ord'])
    lines = []
    for _, r in part.iterrows():
        lines.append(
            f"{r['Group']} & {int(r['RTT'])} & {f2(r['Mean_exact'])} & {f2(r['Median_exact'])} & "
            f"{f2(r['StdDev_exact'])} & {f2(r['P95_exact'])} & "
            f"[{f2(r['CI_low_exact'])}, {f2(r['CI_high_exact'])}] \\\\"
        )
    (OUT / f'scenario_loss_{loss}.tex').write_text('\n'.join(lines) + '\n\\bottomrule\n', encoding='utf-8')

# Pairwise tables.
for group in ['H-512', 'H-768']:
    part = pairwise[pairwise['Comparison'] == f'{group} vs X25519'].sort_values(['Loss', 'RTT'])
    lines = []
    for _, r in part.iterrows():
        p = sci_p(r['p_Holm'])
        lines.append(
            f"{int(r['RTT'])} & {int(r['Loss'])} & "
            f"{f2(r['Median_difference_ms'])} [{f2(r['Median_diff_boot_CI_low'])}, {f2(r['Median_diff_boot_CI_high'])}] & "
            f"{float(r['Cliffs_delta']):.3f} [{float(r['Cliffs_delta_CI_low']):.3f}, {float(r['Cliffs_delta_CI_high']):.3f}] & {p} \\\\"
        )
    safe = group.lower().replace('-', '')
    (OUT / f'pairwise_{safe}.tex').write_text('\n'.join(lines) + '\n\\bottomrule\n', encoding='utf-8')

# Quantile regression table with friendly labels.
label_map = {
    'C(Algorithm)': 'Algorithm',
    'C(RTT)': 'RTT',
    'C(Loss)': 'Loss',
    'C(Algorithm):C(RTT)': r'Algorithm $\times$ RTT',
    'C(Algorithm):C(Loss)': r'Algorithm $\times$ Loss',
    'C(RTT):C(Loss)': r'RTT $\times$ Loss',
    'C(Algorithm):C(RTT):C(Loss)': 'Three-way interaction',
}
lines = []
for _, r in qreg.iterrows():
    term = label_map.get(r['Term'], r['Term'])
    lines.append(f"{term} & {int(r['df_constraints'])} & {float(r['Statistic']):.2f} & {sci_p(r['p_value'])} \\\\ ")
(OUT / 'qreg.tex').write_text('\n'.join(lines) + '\n\\bottomrule\n', encoding='utf-8')

print(f'Generated LaTeX tables in {OUT}')

# Complete IQR-flag audit, split for readability.
iqr = pd.read_csv(DATA / 'high_delay_IQR_observations.csv')
for name, subset in [
    ('iqr_a', iqr[iqr['Group'].isin(['X25519', 'H-512'])]),
    ('iqr_b', iqr[iqr['Group'].isin(['H-768'])]),
]:
    lines = []
    for _, r in subset.iterrows():
        status = 'Fail' if str(r['Status']).lower().startswith('fail') else 'OK'
        lines.append(
            f"{r['Group']} & {int(r['RTT'])}/{int(r['Loss'])} & {int(r['Run'])} & "
            f"{float(r['Handshake_ms']):.2f} / {float(r['IQR_upper_fence']):.2f} & "
            f"{int(r['Retransmissions'])} / {status} \\\\"
        )
    (OUT / f'{name}.tex').write_text('\n'.join(lines) + '\n\\bottomrule\n', encoding='utf-8')
