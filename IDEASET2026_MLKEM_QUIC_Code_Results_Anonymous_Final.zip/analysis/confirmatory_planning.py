from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.stats import binom

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'/'final_pqc_quic_raw_results.csv'
OUT=ROOT/'data'
SEED=20260711
B=5000
N=100

df=pd.read_csv(DATA)
tcol='Handshake Time (ms)'
rtts=sorted(df['RTT (ms)'].unique())
losses=[0,3]

def sign_interval(sample):
    n=len(sample)
    k=int(binom.ppf(0.025,n,0.5))
    s=np.sort(sample)
    # Conservative two-sided order-statistic interval.
    return float(s[k-1]), float(s[n-k])

def evaluate(group, margin=None):
    rng=np.random.default_rng(SEED)
    cells=[]
    for loss in losses:
        for rtt in rtts:
            x=df[(df.Algorithm=='X25519')&(df['RTT (ms)']==rtt)&(df['Packet Loss (%)']==loss)][tcol].to_numpy()
            y=df[(df.Algorithm==group)&(df['RTT (ms)']==rtt)&(df['Packet Loss (%)']==loss)][tcol].to_numpy()
            cells.append((rtt,loss,x,y))
    passed=np.zeros((B,len(cells)),dtype=bool)
    for b in range(B):
        for j,(_,_,x,y) in enumerate(cells):
            xb=x[rng.integers(0,len(x),N)]
            yb=y[rng.integers(0,len(y),N)]
            xlo,xhi=sign_interval(xb); ylo,yhi=sign_interval(yb)
            dlo=ylo-xhi; dhi=yhi-xlo
            if margin is None:
                passed[b,j]=dlo>0
            else:
                passed[b,j]=(dlo>=-margin and dhi<=margin)
    return {
        'joint_probability': float(passed.all(axis=1).mean()),
        'minimum_cell_probability': float(passed.mean(axis=0).min()),
        'cell_probabilities': [float(v) for v in passed.mean(axis=0)],
    }

summary={
    'seed':SEED,
    'resamples':B,
    'candidate_n_per_cell':N,
    'included_loss_profiles':[0,3],
    'h512_within_pm_0_50_ms':evaluate('X25519 + ML-KEM-512',0.50),
    'h512_within_pm_0_25_ms':evaluate('X25519 + ML-KEM-512',0.25),
    'h768_lower_bound_above_zero':evaluate('X25519 + ML-KEM-768',None),
    'interpretation':'Archive-conditioned operational sensitivity only; not a population power guarantee.'
}
(OUT/'confirmatory_planning.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
