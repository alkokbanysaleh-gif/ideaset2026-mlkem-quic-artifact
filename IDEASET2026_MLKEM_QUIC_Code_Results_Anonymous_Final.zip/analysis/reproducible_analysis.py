
#!/usr/bin/env python3
"""
Independent reproducible reanalysis of the ML-KEM / QUIC raw experiment CSV.

Usage:
    python reproducible_analysis.py \
        --input final_pqc_quic_raw_results.csv \
        --output .

The script:
1. audits the 3×4×3×30 design,
2. rebuilds descriptive statistics,
3. checks the manuscript Appendix-A values,
4. calculates bootstrap CIs and Cliff's delta,
5. performs Holm-corrected Mann–Whitney comparisons,
6. runs exploratory median quantile-regression interaction tests,
7. audits retransmissions, failures, and high-delay observations,
8. generates publication-quality figures.

Important:
This validates arithmetic consistency and data structure. It cannot prove
measurement provenance without execution logs, timestamps, VM metadata,
source revisions/build flags, and pcap/qlog.
"""

import argparse
import csv
import math
import statistics
from collections import Counter, defaultdict
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

import numpy as np
from scipy import stats
from statsmodels.stats.multitest import multipletests
import statsmodels.api as sm
from patsy import dmatrix
import matplotlib.pyplot as plt

SEED = 20260711
ALG_ALIAS = {
    "X25519": "X25519",
    "X25519 + ML-KEM-512": "H-512",
    "X25519 + ML-KEM-768": "H-768",
}
ALG_ORDER = ["X25519", "H-512", "H-768"]
RTT_ORDER = [10, 50, 100, 200]
LOSS_ORDER = [0, 1, 3]

EXPECTED_COLUMNS = [
    "Algorithm", "RTT (ms)", "Packet Loss (%)", "Run",
    "Handshake Time (ms)", "Initial Flight Bytes",
    "QUIC Initial Packets", "Retransmissions", "CPU (%)",
    "Peak Memory (MB)", "Status"
]

def half_up(x, digits=2):
    q = Decimal("1").scaleb(-digits)
    return float(Decimal(f"{float(x):.12f}").quantize(q, rounding=ROUND_HALF_UP))

def write_csv(path, rows, fields):
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

def p95(values):
    return float(np.percentile(np.asarray(values, dtype=float), 95, method="linear"))

def t_ci(values):
    a = np.asarray(values, dtype=float)
    n = len(a)
    mean = float(a.mean())
    sd = float(a.std(ddof=1))
    crit = stats.t.ppf(0.975, n - 1)
    half = crit * sd / math.sqrt(n)
    return mean - half, mean + half

def bootstrap_ci(values, kind, n_boot=5000, offset=0):
    a = np.asarray(values, dtype=float)
    rng = np.random.default_rng(SEED + offset)
    idx = rng.integers(0, len(a), size=(n_boot, len(a)))
    samples = a[idx]
    if kind == "median":
        vals = np.median(samples, axis=1)
    elif kind == "p95":
        vals = np.percentile(samples, 95, axis=1, method="linear")
    else:
        raise ValueError(kind)
    lo, hi = np.percentile(vals, [2.5, 97.5], method="linear")
    return float(lo), float(hi)

def cliffs_delta(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    gt = np.sum(x[:, None] > y[None, :])
    lt = np.sum(x[:, None] < y[None, :])
    return float((gt - lt) / (len(x) * len(y)))

def bootstrap_pair(x, y, n_boot=3000, offset=0):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    rng = np.random.default_rng(SEED + offset)
    med_diff = np.empty(n_boot)
    delta = np.empty(n_boot)
    for i in range(n_boot):
        xb = x[rng.integers(0, len(x), len(x))]
        yb = y[rng.integers(0, len(y), len(y))]
        med_diff[i] = np.median(xb) - np.median(yb)
        delta[i] = cliffs_delta(xb, yb)
    md_lo, md_hi = np.percentile(med_diff, [2.5, 97.5], method="linear")
    d_lo, d_hi = np.percentile(delta, [2.5, 97.5], method="linear")
    return float(md_lo), float(md_hi), float(d_lo), float(d_hi)

def delta_magnitude(d):
    a = abs(d)
    if a < 0.147: return "negligible"
    if a < 0.33: return "small"
    if a < 0.474: return "medium"
    return "large"

PAPER_VALUES = """
X25519,10,0,11.99,12.01,0.32,12.44,11.87,12.11
H-512,10,0,12.00,12.00,0.25,12.38,11.91,12.09
H-768,10,0,13.50,13.48,0.31,13.95,13.38,13.61
X25519,50,0,52.01,52.03,0.32,52.48,51.89,52.13
H-512,50,0,52.12,52.14,0.31,52.58,52.01,52.24
H-768,50,0,59.55,59.60,0.27,59.93,59.45,59.66
X25519,100,0,102.08,102.06,0.31,102.58,101.96,102.19
H-512,100,0,102.07,102.03,0.23,102.52,101.98,102.15
H-768,100,0,117.09,117.15,0.34,117.57,116.97,117.22
X25519,200,0,202.15,202.15,0.23,202.48,202.06,202.24
H-512,200,0,202.09,202.13,0.33,202.53,201.97,202.21
H-768,200,0,232.06,232.06,0.26,232.51,231.96,232.16
X25519,10,1,12.03,12.09,0.29,12.46,11.92,12.13
H-512,10,1,11.93,11.88,0.34,12.40,11.80,12.05
H-768,10,1,13.49,13.46,0.28,13.91,13.39,13.60
X25519,50,1,52.11,52.16,0.25,52.46,52.01,52.20
H-512,50,1,52.03,52.02,0.28,52.48,51.92,52.13
H-768,50,1,59.52,59.57,0.30,59.94,59.41,59.64
X25519,100,1,102.13,102.09,0.33,102.77,102.00,102.25
H-512,100,1,101.96,101.94,0.34,102.50,101.84,102.09
H-768,100,1,123.72,117.07,36.54,117.44,110.07,137.36
X25519,200,1,201.95,201.99,0.32,202.44,201.83,202.07
H-512,200,1,201.99,201.96,0.25,202.37,201.89,202.08
H-768,200,1,232.00,231.98,0.33,232.47,231.87,232.12
X25519,10,3,11.98,12.01,0.31,12.47,11.86,12.09
H-512,10,3,14.06,12.10,8.12,23.42,11.02,17.09
H-768,10,3,14.15,13.57,3.72,13.89,12.76,15.54
X25519,50,3,58.64,52.01,25.36,107.21,49.17,68.11
H-512,50,3,51.95,51.96,0.26,52.35,51.86,52.05
H-768,50,3,69.57,59.60,40.23,114.67,54.55,84.59
X25519,100,3,102.00,101.99,0.29,102.45,101.89,102.11
H-512,100,3,108.69,101.98,36.50,102.56,95.06,122.32
H-768,100,3,123.57,116.87,36.49,117.47,109.94,137.20
X25519,200,3,202.08,202.08,0.30,202.63,201.96,202.19
H-512,200,3,215.30,201.90,73.10,202.60,188.01,242.60
H-768,200,3,271.99,231.96,161.04,452.31,211.86,332.13
""".strip()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()
    input_path = Path(args.input)
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    fig_dir = out / "figures"
    fig_dir.mkdir(exist_ok=True)

    records = []
    with open(input_path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        actual_columns = reader.fieldnames
        for row in reader:
            raw_alg = row["Algorithm"].strip()
            if raw_alg not in ALG_ALIAS:
                raise ValueError(f"Unknown algorithm label: {raw_alg}")
            records.append({
                "Algorithm": ALG_ALIAS[raw_alg],
                "RawAlgorithm": raw_alg,
                "RTT": int(row["RTT (ms)"]),
                "Loss": int(row["Packet Loss (%)"]),
                "Run": int(row["Run"]),
                "Handshake": float(row["Handshake Time (ms)"]),
                "Payload": int(row["Initial Flight Bytes"]),
                "InitialPackets": int(row["QUIC Initial Packets"]),
                "Retransmissions": int(row["Retransmissions"]),
                "CPU": float(row["CPU (%)"]),
                "Memory": float(row["Peak Memory (MB)"]),
                "Status": row["Status"].strip(),
            })

    cells = defaultdict(list)
    for r in records:
        cells[(r["Algorithm"], r["RTT"], r["Loss"])].append(r)

    audit = []
    audit.append({"Check":"Schema", "Value":str(actual_columns), "Status":"PASS" if actual_columns == EXPECTED_COLUMNS else "FAIL"})
    audit.append({"Check":"Total rows", "Value":len(records), "Status":"PASS" if len(records)==1080 else "FAIL"})
    audit.append({"Check":"Scenario cells", "Value":len(cells), "Status":"PASS" if len(cells)==36 else "FAIL"})
    bad_counts, bad_runs = [], []
    for key, rows in cells.items():
        if len(rows) != 30: bad_counts.append((key, len(rows)))
        if sorted(r["Run"] for r in rows) != list(range(1,31)): bad_runs.append(key)
    audit.append({"Check":"30 runs per cell", "Value":str(bad_counts), "Status":"PASS" if not bad_counts else "FAIL"})
    audit.append({"Check":"Run IDs 1–30 per cell", "Value":str(bad_runs), "Status":"PASS" if not bad_runs else "FAIL"})
    tuples = [tuple(r[k] for k in ("Algorithm","RTT","Loss","Run","Handshake","Payload","InitialPackets","Retransmissions","CPU","Memory","Status")) for r in records]
    duplicates = len(tuples)-len(set(tuples))
    audit.append({"Check":"Exact duplicate rows", "Value":duplicates, "Status":"PASS" if duplicates==0 else "WARN"})
    status_counts = Counter(r["Status"] for r in records)
    audit.append({"Check":"Success rows", "Value":status_counts.get("Success",0), "Status":"PASS"})
    audit.append({"Check":"Failure rows", "Value":status_counts.get("Failure",0), "Status":"PASS" if status_counts.get("Failure",0)==1 else "WARN"})
    for label in ("Timestamp field","Random seed field","pcap/qlog linkage","Source commit/build flags"):
        audit.append({"Check":label, "Value":"Not present in CSV", "Status":"LIMITATION"})
    write_csv(out/"data_audit.csv", audit, ["Check","Value","Status"])

    summary = []
    counter = 0
    for alg in ALG_ORDER:
        for loss in LOSS_ORDER:
            for rtt in RTT_ORDER:
                rows = cells[(alg,rtt,loss)]
                if len(rows) != 30:
                    raise ValueError(f"Incomplete cell {(alg,rtt,loss)}: {len(rows)}")
                vals = [r["Handshake"] for r in rows]
                mean = float(np.mean(vals)); median = float(np.median(vals))
                sd = float(np.std(vals,ddof=1)); perc95 = p95(vals)
                ci_lo,ci_hi = t_ci(vals)
                mlo,mhi = bootstrap_ci(vals,"median",offset=1000+counter)
                plo,phi = bootstrap_ci(vals,"p95",offset=2000+counter)
                counter += 1
                summary.append({
                    "Group":alg,"RTT":rtt,"Loss":loss,"N":30,
                    "Mean_exact":mean,"Median_exact":median,"StdDev_exact":sd,"P95_exact":perc95,
                    "CI_low_exact":ci_lo,"CI_high_exact":ci_hi,
                    "Median_boot_CI_low":mlo,"Median_boot_CI_high":mhi,
                    "P95_boot_CI_low":plo,"P95_boot_CI_high":phi,
                    "Mean_2dp":half_up(mean),"Median_2dp":half_up(median),
                    "StdDev_2dp":half_up(sd),"P95_2dp":half_up(perc95),
                    "CI_low_2dp":half_up(ci_lo),"CI_high_2dp":half_up(ci_hi),
                })
    write_csv(out/"final_pqc_quic_statistical_summary_rebuilt.csv",summary,list(summary[0]))

    aggregate = []
    for alg in ALG_ORDER:
        sub=[r for r in records if r["Algorithm"]==alg]
        cpu=[r["CPU"] for r in sub]; mem=[r["Memory"] for r in sub]
        aggregate.append({
            "Group":alg,"Runs":len(sub),
            "Payload_B":statistics.mode(r["Payload"] for r in sub),
            "Initial_Packets":statistics.mode(r["InitialPackets"] for r in sub),
            "CPU_mean":float(np.mean(cpu)),"CPU_sd":float(np.std(cpu,ddof=1)),
            "Memory_mean":float(np.mean(mem)),"Memory_sd":float(np.std(mem,ddof=1)),
            "Retransmission_events":sum(r["Retransmissions"] for r in sub),
            "Runs_with_retransmission":sum(r["Retransmissions"]>0 for r in sub),
            "Failures":sum(r["Status"]!="Success" for r in sub),
            "Max_handshake_ms":max(r["Handshake"] for r in sub),
        })
    write_csv(out/"aggregate_group_summary.csv",aggregate,list(aggregate[0]))

    paper={}
    for line in PAPER_VALUES.splitlines():
        p=line.split(","); key=(p[0],int(p[1]),int(p[2]))
        paper[key]={"Mean":float(p[3]),"Median":float(p[4]),"StdDev":float(p[5]),
                    "P95":float(p[6]),"CI_low":float(p[7]),"CI_high":float(p[8])}
    checks=[]
    metric_map=[("Mean","Mean_exact"),("Median","Median_exact"),("StdDev","StdDev_exact"),
                ("P95","P95_exact"),("CI_low","CI_low_exact"),("CI_high","CI_high_exact")]
    for s in summary:
        key=(s["Group"],s["RTT"],s["Loss"])
        for pm,cm in metric_map:
            d=s[cm]-paper[key][pm]
            checks.append({
                "Group":s["Group"],"RTT":s["RTT"],"Loss":s["Loss"],"Metric":pm,
                "Paper_value":paper[key][pm],"Calculated_exact":s[cm],
                "Calculated_HALF_UP_2dp":half_up(s[cm]),
                "Difference_exact_minus_paper":d,
                "Matches_within_0.01":abs(d)<0.010000000001
            })
    write_csv(out/"manuscript_consistency_check.csv",checks,list(checks[0]))

    pairwise=[]; pvals=[]; temp=[]; counter=0
    for loss in LOSS_ORDER:
        for rtt in RTT_ORDER:
            base=[r["Handshake"] for r in cells[("X25519",rtt,loss)]]
            for alg in ("H-512","H-768"):
                comp=[r["Handshake"] for r in cells[(alg,rtt,loss)]]
                md=float(np.median(comp)-np.median(base))
                pct=float(100*md/np.median(base))
                delta=cliffs_delta(comp,base)
                mdlo,mdhi,dlo,dhi=bootstrap_pair(comp,base,offset=3000+counter); counter+=1
                u=stats.mannwhitneyu(comp,base,alternative="two-sided",method="auto")
                pvals.append(float(u.pvalue))
                temp.append({
                    "Comparison":f"{alg} vs X25519","RTT":rtt,"Loss":loss,"N_each":30,
                    "Median_difference_ms":md,"Median_difference_pct":pct,
                    "Median_diff_boot_CI_low":mdlo,"Median_diff_boot_CI_high":mdhi,
                    "Cliffs_delta":delta,"Cliffs_delta_CI_low":dlo,"Cliffs_delta_CI_high":dhi,
                    "Effect_magnitude":delta_magnitude(delta),
                    "Mann_Whitney_U":float(u.statistic),"p_raw":float(u.pvalue),
                })
    reject,padj,_,_=multipletests(pvals,alpha=0.05,method="holm")
    for row,pa,rj in zip(temp,padj,reject):
        row["p_Holm"]=float(pa); row["Reject_at_0.05"]=bool(rj); pairwise.append(row)
    write_csv(out/"pairwise_bootstrap_effect_sizes.csv",pairwise,list(pairwise[0]))

    retx=[]
    for alg in ALG_ORDER:
        sub=[r for r in records if r["Algorithm"]==alg]
        rr=sum(r["Retransmissions"]>0 for r in sub)
        fail=sum(r["Status"]!="Success" for r in sub)
        retx.append({
            "Group":alg,"Runs":len(sub),
            "Retransmission_events":sum(r["Retransmissions"] for r in sub),
            "Runs_with_retransmission":rr,"Retransmission_run_rate":rr/len(sub),
            "Failures":fail,"Failure_rate":fail/len(sub),
        })
    write_csv(out/"retransmission_failure_analysis.csv",retx,list(retx[0]))

    base=next(x for x in retx if x["Group"]=="X25519")
    fish=[]
    for alg in ("H-512","H-768"):
        comp=next(x for x in retx if x["Group"]==alg)
        table=[[comp["Runs_with_retransmission"],comp["Runs"]-comp["Runs_with_retransmission"]],
               [base["Runs_with_retransmission"],base["Runs"]-base["Runs_with_retransmission"]]]
        odds,pv=stats.fisher_exact(table)
        fish.append({"Comparison":f"{alg} vs X25519","Odds_ratio":float(odds),
                     "Fisher_p":float(pv),"Note":"Exploratory; sparse retransmission runs."})
    write_csv(out/"retransmission_fisher_tests.csv",fish,list(fish[0]))

    outliers=[]
    for alg in ALG_ORDER:
        for loss in LOSS_ORDER:
            for rtt in RTT_ORDER:
                rows=cells[(alg,rtt,loss)]
                vals=np.array([r["Handshake"] for r in rows])
                q1,q3=np.percentile(vals,[25,75],method="linear")
                upper=float(q3+1.5*(q3-q1))
                for r in rows:
                    if r["Handshake"]>upper:
                        outliers.append({
                            "Group":alg,"RTT":rtt,"Loss":loss,"Run":r["Run"],
                            "Handshake_ms":r["Handshake"],"IQR_upper_fence":upper,
                            "Retransmissions":r["Retransmissions"],"Status":r["Status"]
                        })
    write_csv(out/"high_delay_IQR_observations.csv",outliers,list(outliers[0]))

    # Exploratory median quantile-regression interaction tests.
    data={
        "Algorithm":[r["Algorithm"] for r in records],
        "RTT":[str(r["RTT"]) for r in records],
        "Loss":[str(r["Loss"]) for r in records],
    }
    X=dmatrix("C(Algorithm) * C(RTT) * C(Loss)",data,return_type="matrix")
    y=np.array([r["Handshake"] for r in records])
    qres=sm.QuantReg(y,X).fit(q=0.5,max_iter=10000)
    interactions=[]
    for term,sl in X.design_info.term_name_slices.items():
        if term=="Intercept": continue
        idx=list(range(sl.start,sl.stop))
        R=np.zeros((len(idx),X.shape[1]))
        for i,j in enumerate(idx): R[i,j]=1
        wt=qres.wald_test(R,scalar=True)
        interactions.append({
            "Term":term,"Statistic":float(wt.statistic),"p_value":float(wt.pvalue),
            "df_constraints":len(idx),
            "Method":"Median quantile regression joint Wald test",
            "Note":"Exploratory asymptotic inference; use bootstrap effects as primary evidence."
        })
    write_csv(out/"quantile_regression_interaction_tests.csv",interactions,list(interactions[0]))
    (out/"quantile_regression_summary.txt").write_text(qres.summary().as_text(),encoding="utf-8")

    # Figures: one chart per figure.
    plt.figure(figsize=(7.2,4.8))
    for alg in ALG_ORDER:
        vals=np.sort([r["Handshake"] for r in cells[(alg,200,3)]])
        yy=np.arange(1,len(vals)+1)/len(vals)
        plt.step(vals,yy,where="post",label=alg)
    plt.xlabel("Handshake time (ms)"); plt.ylabel("Empirical cumulative probability")
    plt.title("ECDF: 200 ms RTT / named 3% loss profile"); plt.legend(); plt.tight_layout()
    plt.savefig(fig_dir/"ecdf_critical_200ms_3pct.png",dpi=300); plt.close()

    for loss in LOSS_ORDER:
        plt.figure(figsize=(7.2,4.8))
        for alg in ALG_ORDER:
            med=[]; elo=[]; ehi=[]
            for rtt in RTT_ORDER:
                s=next(x for x in summary if x["Group"]==alg and x["Loss"]==loss and x["RTT"]==rtt)
                med.append(s["Median_exact"])
                elo.append(s["Median_exact"]-s["Median_boot_CI_low"])
                ehi.append(s["Median_boot_CI_high"]-s["Median_exact"])
            plt.errorbar(RTT_ORDER,med,yerr=[elo,ehi],marker="o",capsize=3,label=alg)
        plt.xlabel("Configured RTT (ms)"); plt.ylabel("Median handshake time (ms)")
        plt.title(f"Median interaction with 95% bootstrap CI — named {loss}% loss")
        plt.legend(); plt.tight_layout()
        plt.savefig(fig_dir/f"median_interaction_loss_{loss}.png",dpi=300); plt.close()

    selected=[r for r in pairwise if r["Comparison"]=="H-768 vs X25519"]
    labels=[f"RTT {r['RTT']} / loss {r['Loss']}%" for r in selected]
    vals=[r["Cliffs_delta"] for r in selected]
    lo=[r["Cliffs_delta"]-r["Cliffs_delta_CI_low"] for r in selected]
    hi=[r["Cliffs_delta_CI_high"]-r["Cliffs_delta"] for r in selected]
    ypos=np.arange(len(labels))
    plt.figure(figsize=(7.5,6.5))
    plt.errorbar(vals,ypos,xerr=[lo,hi],fmt="o",capsize=3)
    plt.axvline(0,linewidth=1); plt.yticks(ypos,labels)
    plt.xlabel("Cliff's delta (H-768 minus X25519)")
    plt.title("Effect sizes across network conditions"); plt.tight_layout()
    plt.savefig(fig_dir/"effect_sizes_H768_vs_X25519.png",dpi=300); plt.close()

    for alg in ALG_ORDER:
        mat=np.zeros((len(LOSS_ORDER),len(RTT_ORDER)))
        for i,loss in enumerate(LOSS_ORDER):
            for j,rtt in enumerate(RTT_ORDER):
                mat[i,j]=sum(r["Retransmissions"] for r in cells[(alg,rtt,loss)])
        plt.figure(figsize=(6.5,3.8))
        im=plt.imshow(mat,aspect="auto"); plt.colorbar(im,label="Retransmission events")
        plt.xticks(range(len(RTT_ORDER)),RTT_ORDER); plt.yticks(range(len(LOSS_ORDER)),[f"{x}%" for x in LOSS_ORDER])
        plt.xlabel("Configured RTT (ms)"); plt.ylabel("Named loss profile")
        plt.title(f"Retransmission-event heatmap — {alg}")
        for i in range(mat.shape[0]):
            for j in range(mat.shape[1]):
                plt.text(j,i,int(mat[i,j]),ha="center",va="center")
        plt.tight_layout(); plt.savefig(fig_dir/f"retransmission_heatmap_{alg}.png",dpi=300); plt.close()

    max_diff=max(abs(r["Difference_exact_minus_paper"]) for r in checks)
    all_match=all(r["Matches_within_0.01"] for r in checks)
    report=f"""INDEPENDENT DATA AUDIT AND REANALYSIS
=====================================
Input: {input_path.name}
Rows: {len(records)}
Scenario cells: {len(cells)}
Runs per cell: 30
Successes: {status_counts.get('Success',0)}
Failures: {status_counts.get('Failure',0)}
Exact duplicates: {duplicates}

MANUSCRIPT CONSISTENCY
Compared values: {len(checks)} (36 scenarios × 6 statistics)
All values match within 0.01 ms: {all_match}
Maximum absolute exact difference: {max_diff:.6f} ms

PROVENANCE LIMITATION
The CSV validates arithmetic consistency, not the origin of the measurements.
Missing evidence includes timestamps, original execution logs, VM metadata,
source revisions/build flags, and pcap/qlog.
"""
    (out/"data_audit_report.txt").write_text(report,encoding="utf-8")

    methodology=f"""# Analysis methodology

- Raw observations: {len(records)}
- Design: 3 algorithms × 4 RTTs × 3 loss profiles × 30 runs.
- P95: NumPy linear interpolation.
- Mean CI: two-sided 95% t interval.
- Median and P95 uncertainty: 5,000 percentile-bootstrap resamples.
- Pairwise comparisons: median difference, Cliff's delta, Mann–Whitney U,
  Holm correction across 24 tests.
- Interaction analysis: full-factorial median quantile regression.
- Reproducibility seed: {SEED}.
- Failure inference remains descriptive because only one failure was observed.
"""
    (out/"analysis_methodology.md").write_text(methodology,encoding="utf-8")
    print(report)

if __name__ == "__main__":
    main()
