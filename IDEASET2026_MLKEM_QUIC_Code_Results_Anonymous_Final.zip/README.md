# Anonymous code, data, and results artifact

This artifact contains the archived 1,080-row CSV, analysis scripts, generated results, and an anonymous copy of the paper source.

Windows users can run `RUN_REPRODUCTION.ps1` or `RUN_REPRODUCTION.bat`. Cross-platform users can install `analysis/requirements.txt` and run:

```bash
python reproduce_results.py
```

The regenerated files are written to `results_regenerated/`. The script verifies the raw-data SHA-256 before analysis. This artifact reproduces the analysis, not the unavailable provenance of the original cloud measurement runs. The 2,400-attempt campaign is prospective only.
