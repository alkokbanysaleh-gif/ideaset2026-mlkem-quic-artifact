@echo off
setlocal
cd /d "%~dp0"
python -m venv .venv || exit /b 1
call .venv\Scripts\activate.bat || exit /b 1
python -m pip install --upgrade pip || exit /b 1
python -m pip install -r analysis\requirements.txt || exit /b 1
python reproduce_results.py || exit /b 1
echo Finished. Open results_regenerated.
endlocal
