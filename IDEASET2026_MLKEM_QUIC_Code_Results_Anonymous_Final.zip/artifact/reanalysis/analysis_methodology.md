# Analysis methodology

- Raw observations: 1080
- Design: 3 algorithms × 4 RTTs × 3 loss profiles × 30 runs.
- P95: NumPy linear interpolation.
- Mean CI: two-sided 95% t interval.
- Median and P95 uncertainty: 5,000 percentile-bootstrap resamples.
- Pairwise comparisons: median difference, Cliff's delta, Mann–Whitney U,
  Holm correction across 24 tests.
- Interaction analysis: full-factorial median quantile regression.
- Reproducibility seed: 20260711.
- Failure inference remains descriptive because only one failure was observed.
