$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    throw "Python is not installed or is not available in PATH."
}

if (-not (Test-Path ".venv")) {
    python -m venv .venv
}

& ".\.venv\Scripts\python.exe" -m pip install --upgrade pip
& ".\.venv\Scripts\python.exe" -m pip install -r "analysis\requirements.txt"
& ".\.venv\Scripts\python.exe" reproduce_results.py

Write-Host "Finished. Open results_regenerated." -ForegroundColor Green
