# Anonymous Overleaf package - IDEASET 2026

Upload this ZIP directly through **New Project > Upload Project**. Confirm that `main.tex` is selected as the Main document and use the `pdfLaTeX` compiler.

The project is self-contained: references are embedded in `main.tex`, and all required tables and figures are pre-generated. The expected output is a seven-page anonymous IEEE conference paper.

Do not insert author names, affiliations, email addresses, acknowledgements, or identifying metadata before double-blind review is complete.
